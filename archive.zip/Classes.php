<?php

include_once 'CarType/RoadType.php';
include_once 'CarType/UrbanRoad.php';
include_once 'CarType/RuralRoad.php';
include_once 'Duration.php';
include_once 'FuelStation.php';
include_once 'Journey.php';
include_once 'RoadMap.php';
include "db.php";


?>